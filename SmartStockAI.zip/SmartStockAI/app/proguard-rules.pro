# ProGuard rules for SmartStockAI
