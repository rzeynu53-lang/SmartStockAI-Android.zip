package com.example.smartstock

import android.content.Context
import org.json.JSONObject

object StorageHelper {
    private const val PREF_NAME = "smart_stock_prefs"
    private const val KEY_STOCK = "stock_items"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_MODEL = "gemini_model"

    fun loadStock(context: Context): Map<String, Int> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_STOCK, "{}") ?: "{}"
        val map = linkedMapOf<String, Int>()
        try {
            val json = JSONObject(jsonStr)
            json.keys().forEach { key ->
                map[key] = json.optInt(key, 0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return map
    }

    fun saveStock(context: Context, stock: Map<String, Int>) {
        val json = JSONObject()
        stock.forEach { (k, v) -> json.put(k, v) }
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_STOCK, json.toString())
            .apply()
    }

    fun getApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_API, "")?.trim() ?: ""
    }

    fun saveApiKey(context: Context, apiKey: String) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_API, apiKey.trim())
            .apply()
    }

    fun getModel(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_MODEL, "")?.trim() ?: ""
    }

    fun saveModel(context: Context, model: String) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MODEL, model.trim())
            .apply()
    }
}
