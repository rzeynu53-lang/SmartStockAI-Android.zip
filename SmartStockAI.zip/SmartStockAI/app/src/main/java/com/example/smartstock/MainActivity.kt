package com.example.smartstock

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SmartStockApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartStockApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var stock by remember { mutableStateOf(StorageHelper.loadStock(context)) }
    var showSettings by remember { mutableStateOf(false) }
    var statusBanner by remember { mutableStateOf<String?>(null) }

    fun updateStock(newStock: Map<String, Int>, message: String? = null) {
        stock = newStock
        StorageHelper.saveStock(context, newStock)
        if (message != null) statusBanner = message
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SmartStock AI", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { showSettings = true }) {
                        Text("⚙️ API Key")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("መጋዘን") },
                    icon = { Text("📦") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text("እቃ መቀበያ") },
                    icon = { Text("🔍") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    label = { Text("ሽያጭ") },
                    icon = { Text("📝") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            if (statusBanner != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(statusBanner!!, modifier = Modifier.weight(1f))
                        TextButton(onClick = { statusBanner = null }) { Text("እሺ") }
                    }
                }
            }

            when (selectedTab) {
                0 -> StockScreen(stock, ::updateStock)
                1 -> CompareScreen(stock, ::updateStock)
                2 -> SalesScreen(stock, ::updateStock)
            }
        }
    }

    if (showSettings) {
        ApiKeyDialog(
            initialKey = StorageHelper.getApiKey(context),
            onDismiss = { showSettings = false },
            onSave = { newKey ->
                StorageHelper.saveApiKey(context, newKey)
                StorageHelper.saveModel(context, "")
                showSettings = false
                statusBanner = "✅ Gemini API Key ተቀምጧል።"
            }
        )
    }
}

@Composable
fun ApiKeyDialog(
    initialKey: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var apiKey by remember { mutableStateOf(initialKey) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Gemini API Key ቅንብር") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ከ Google AI Studio ያገኘኸውን ነፃ Gemini API Key እዚህ አስገባ፦")
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API Key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(apiKey) }) { Text("አስቀምጥ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ተው") }
        }
    )
}

@Composable
fun ProgressStatusCard(percent: Int, label: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label, style = MaterialTheme.typography.bodyMedium)
                Text("$percent%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            LinearProgressIndicator(
                progress = { (percent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun StockScreen(
    stock: Map<String, Int>,
    onUpdate: (Map<String, Int>, String?) -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var itemQty by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }

    val totalUnits = stock.values.sum()
    val filteredList = stock.entries.filter {
        searchQuery.isBlank() || it.key.contains(searchQuery, ignoreCase = true)
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "የመጋዘን ቀሪ እቃዎች (${stock.size} ዓይነት | ጠቅላላ: $totalUnits)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = itemName,
                onValueChange = { itemName = it },
                label = { Text("የእቃ ስም") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = itemQty,
                onValueChange = { itemQty = it.filter { ch -> ch.isDigit() } },
                label = { Text("ብዛት") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(95.dp)
            )
        }

        Button(
            onClick = {
                val qty = itemQty.toIntOrNull() ?: 0
                if (itemName.isNotBlank() && qty > 0) {
                    val updated = stock.toMutableMap()
                    val cleanName = itemName.trim()
                    updated[cleanName] = (updated[cleanName] ?: 0) + qty
                    onUpdate(updated, "✅ $cleanName (+$qty) ወደ መጋዘን ገብቷል።")
                    itemName = ""
                    itemQty = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("+ ወደ መጋዘን ጨምር") }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("እቃ ፈልግ...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        HorizontalDivider()

        if (filteredList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("ምንም የተመዘገበ እቃ የለም።")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredList, key = { it.key }) { (name, qty) ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                Text("ቀሪ ብዛት: $qty", style = MaterialTheme.typography.bodyMedium)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val updated = stock.toMutableMap()
                                        updated[name] = (qty - 1).coerceAtLeast(0)
                                        onUpdate(updated, null)
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) { Text("-") }

                                OutlinedButton(
                                    onClick = {
                                        val updated = stock.toMutableMap()
                                        updated[name] = qty + 1
                                        onUpdate(updated, null)
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) { Text("+") }

                                TextButton(
                                    onClick = {
                                        val updated = stock.toMutableMap()
                                        updated.remove(name)
                                        onUpdate(updated, "🗑️ $name ተሰርዟል።")
                                    }
                                ) { Text("✕") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompareScreen(
    stock: Map<String, Int>,
    onUpdate: (Map<String, Int>, String?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var sentUri by remember { mutableStateOf<Uri?>(null) }
    var recUri by remember { mutableStateOf<Uri?>(null) }
    var result by remember { mutableStateOf<CargoComparisonResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var progressPercent by remember { mutableIntStateOf(0) }
    var progressLabel by remember { mutableStateOf("") }

    val sentPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { sentUri = it }
    val recPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { recUri = it }

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("የተላከ እና የደረሰ እቃ መቀበያ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        OutlinedButton(onClick = { sentPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (sentUri == null) "1. ላኪው የላከውን ፎቶ ምረጥ (አማራጭ)" else "✅ የተላከው ፎቶ ተመርጧል")
        }

        OutlinedButton(onClick = { recPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (recUri == null) "2. የደረሰህን እቃ ፎቶ ምረጥ" else "✅ የደረሰው ፎቶ ተመርጧል")
        }

        Button(
            enabled = recUri != null && !loading,
            onClick = {
                loading = true
                result = null
                progressPercent = 5
                progressLabel = "በመጀመር ላይ..."

                val tickerJob = scope.launch {
                    while (true) {
                        delay(500)
                        if (progressPercent in 50..92) {
                            progressPercent += 3
                            progressLabel = "AI ፎቶዎቹን እየመረመረ ነው..."
                        }
                    }
                }

                scope.launch {
                    val onProg: (Int, String) -> Unit = { p, lbl ->
                        if (p > progressPercent) progressPercent = p
                        progressLabel = lbl
                    }
                    result = if (sentUri != null) {
                        GeminiService.compareCargoPhotos(context, sentUri!!, recUri!!, stock.keys.toList(), onProg)
                    } else {
                        GeminiService.countSinglePhoto(context, recUri!!, stock.keys.toList(), onProg)
                    }
                    tickerJob.cancel()
                    loading = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                when {
                    loading -> "በመስራት ላይ... ($progressPercent%)"
                    sentUri != null -> "🔍 የጎደለውን ለይ እና የደረሰውን ቁጠር"
                    else -> "📦 የደረሰውን እቃ ቁጠር"
                }
            )
        }

        if (loading) {
            ProgressStatusCard(progressPercent, progressLabel)
        }

        result?.error?.let { err ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(err, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        result?.takeIf { it.error == null }?.let { res ->
            if (res.summaryText.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("የAI ማነፃፀሪያ ውጤት፦", fontWeight = FontWeight.Bold)
                        Text(res.summaryText)
                    }
                }
            }

            if (res.receivedItems.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("የደረሱ እቃዎች (ወደ መጋዘን የሚገቡ)፦", fontWeight = FontWeight.Bold)
                        res.receivedItems.forEach { (name, qty) ->
                            Text("• $name : +$qty")
                        }
                        Spacer(Modifier.height(6.dp))
                        Button(
                            onClick = {
                                val updated = stock.toMutableMap()
                                res.receivedItems.forEach { (name, qty) ->
                                    updated[name] = (updated[name] ?: 0) + qty
                                }
                                onUpdate(updated, "✅ ${res.receivedItems.size} ዓይነት እቃዎች ወደ መጋዘን ተጨምረዋል።")
                                result = null
                                sentUri = null
                                recUri = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("አረጋግጥ እና ወደ መጋዘን ጨምር") }
                    }
                }
            }
        }
    }
}

@Composable
fun SalesScreen(
    stock: Map<String, Int>,
    onUpdate: (Map<String, Int>, String?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var notebookUri by remember { mutableStateOf<Uri?>(null) }
    var parsedSales by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var progressPercent by remember { mutableIntStateOf(0) }
    var progressLabel by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { notebookUri = it }

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("የሽያጭ ደብተር ማንበቢያ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (notebookUri == null) "የሽያጭ ደብተር ፎቶ ምረጥ" else "✅ የደብተር ፎቶ ተመርጧል")
        }

        Button(
            enabled = notebookUri != null && !loading,
            onClick = {
                loading = true
                errorMsg = null
                parsedSales = emptyMap()
                progressPercent = 5
                progressLabel = "በመጀመር ላይ..."

                val tickerJob = scope.launch {
                    while (true) {
                        delay(500)
                        if (progressPercent in 50..92) {
                            progressPercent += 3
                            progressLabel = "AI ደብተሩን እያነበበ ነው..."
                        }
                    }
                }

                scope.launch {
                    val onProg: (Int, String) -> Unit = { p, lbl ->
                        if (p > progressPercent) progressPercent = p
                        progressLabel = lbl
                    }
                    val res = GeminiService.parseSalesNotebook(context, notebookUri!!, stock.keys.toList(), onProg)
                    parsedSales = res.soldItems
                    errorMsg = res.error
                    tickerJob.cancel()
                    loading = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (loading) "በማንበብ ላይ... ($progressPercent%)" else "📝 የተሸጡትን አንብብ") }

        if (loading) {
            ProgressStatusCard(progressPercent, progressLabel)
        }

        errorMsg?.let { err ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(err, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        if (parsedSales.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ከደብተሩ የተነበቡ ሽያጮች፦", fontWeight = FontWeight.Bold)
                    parsedSales.forEach { (name, qty) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("• $name : -$qty", modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                val mutable = parsedSales.toMutableMap()
                                mutable.remove(name)
                                parsedSales = mutable
                            }) { Text("አስወግድ") }
                        }
                    }
                    Button(
                        onClick = {
                            val updated = stock.toMutableMap()
                            parsedSales.forEach { (name, soldQty) ->
                                val current = updated[name] ?: 0
                                updated[name] = (current - soldQty).coerceAtLeast(0)
                            }
                            onUpdate(updated, "✅ ሽያጩ ከመጋዘን ላይ ተቀንሷል።")
                            parsedSales = emptyMap()
                            notebookUri = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("አረጋግጥ እና ከመጋዘን ቀንስ") }
                }
            }
        }
    }
}
