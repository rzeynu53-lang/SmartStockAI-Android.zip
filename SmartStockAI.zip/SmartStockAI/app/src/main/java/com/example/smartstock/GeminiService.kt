package com.example.smartstock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.max

data class CargoComparisonResult(
    val summaryText: String,
    val receivedItems: Map<String, Int>,
    val error: String? = null
)

data class SalesParseResult(
    val soldItems: Map<String, Int>,
    val error: String? = null
)

object GeminiService {
    private const val MODEL = "gemini-2.5-flash"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    // ትላልቅ ፎቶዎችን (እንደ 200MP) ስልኩን ሳያጨናንቁ ወደ ተመጣጣኝ መጠን (1280px) መቀየር
    private fun uriToBase64(context: Context, uri: Uri, maxDim: Int = 1280): String {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("ፎቶውን መክፈት አልተቻለም።")
        val original = inputStream.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalStateException("ፎቶውን ማንበብ አልተቻለም።")

        val width = original.width
        val height = original.height
        val longest = max(width, height)

        val scaled = if (longest > maxDim) {
            val scale = maxDim.toFloat() / longest.toFloat()
            Bitmap.createScaledBitmap(
                original,
                (width * scale).toInt().coerceAtLeast(1),
                (height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else {
            original
        }

        val outputStream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        if (scaled !== original) {
            scaled.recycle()
        }
        original.recycle()
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    // 1. የተላከ እና የደረሰ እቃ ፎቶ ማነፃፀር + የደረሱ እቃዎችን ዝርዝር ማውጣት
    suspend fun compareCargoPhotos(
        context: Context,
        sentUri: Uri,
        receivedUri: Uri,
        existingStockNames: List<String>
    ): CargoComparisonResult = withContext(Dispatchers.IO) {
        val apiKey = StorageHelper.getApiKey(context)
        if (apiKey.isBlank()) {
            return@withContext CargoComparisonResult(
                summaryText = "",
                receivedItems = emptyMap(),
                error = "እባክህ መጀመሪያ ከላይ ያለውን ⚙️ (ቅንብሮች) በመጫን Gemini API Key አስገባ።"
            )
        }

        try {
            val sentB64 = uriToBase64(context, sentUri)
            val recB64 = uriToBase64(context, receivedUri)
            val existingList = if (existingStockNames.isEmpty()) "የለም" else existingStockNames.joinToString(", ")

            val prompt = """
                እነዚህን ሁለት ፎቶዎች በጥንቃቄ አነፃፅር።
                1ኛው ፎቶ: ላኪው የላከው እቃ ነው።
                2ኛው ፎቶ: ተቀባዩ የደረሰው እቃ ነው።
                አሁን መጋዘን ውስጥ ያሉት እቃዎች ስም: [$existingList]

                ሁለት ነገር ስራ፦
                1. በ1ኛው ፎቶ ላይ የነበረ ግን በ2ኛው ፎቶ ላይ የጎደለ ወይም ቁጥሩ የቀነሰ እቃ ካለ በአማርኛ ግልፅ ሪፖርት ("summary") ጻፍ።
                2. በ2ኛው ፎቶ (የደረሰው) ላይ የሚታዩትን እቃዎች ስም እና ብዛት ("received_items") ዘርዝር። ከመጋዘኑ ስም ጋር የሚመሳሰል ካለ ያንኑ ስም ተጠቀም።

                ውጤቱን በዚህ JSON ቅርፅ ብቻ መልስ (ምንም ተጨማሪ ጽሑፍ ሳትጨምር):
                {
                  "summary": "የጎደሉ እቃዎች ሪፖርት በአማርኛ...",
                  "received_items": {
                    "የእቃ ስም 1": 2,
                    "የእቃ ስም 2": 5
                  }
                }
            """.trimIndent()

            val raw = callGemini(apiKey, prompt, listOf(sentB64, recB64))
            val cleaned = cleanJson(raw)
            val json = JSONObject(cleaned)

            val summary = json.optString("summary", raw)
            val itemsObj = json.optJSONObject("received_items")
            val receivedMap = linkedMapOf<String, Int>()
            if (itemsObj != null) {
                itemsObj.keys().forEach { key ->
                    val count = itemsObj.optInt(key, 0)
                    if (count > 0) receivedMap[key] = count
                }
            }

            CargoComparisonResult(summaryText = summary, receivedItems = receivedMap)
        } catch (e: Exception) {
            CargoComparisonResult(
                summaryText = "",
                receivedItems = emptyMap(),
                error = "ስህተት ተፈጥሯል: ${e.message}"
            )
        }
    }

    // 2. የደረሰ እቃ ብቻ (1 ፎቶ) ቆጥሮ ወደ መጋዘን ለማስገባት
    suspend fun countSinglePhoto(
        context: Context,
        photoUri: Uri,
        existingStockNames: List<String>
    ): CargoComparisonResult = withContext(Dispatchers.IO) {
        val apiKey = StorageHelper.getApiKey(context)
        if (apiKey.isBlank()) {
            return@withContext CargoComparisonResult(
                summaryText = "",
                receivedItems = emptyMap(),
                error = "እባክህ መጀመሪያ ከላይ ያለውን ⚙️ (ቅንብሮች) በመጫን Gemini API Key አስገባ።"
            )
        }

        try {
            val b64 = uriToBase64(context, photoUri)
            val existingList = if (existingStockNames.isEmpty()) "የለም" else existingStockNames.joinToString(", ")

            val prompt = """
                በዚህ ፎቶ ላይ የሚታዩትን እቃዎች በሙሉ ለይተህ ቁጠር።
                አሁን መጋዘን ውስጥ ያሉት እቃዎች ስም: [$existingList]
                የሚመሳሰል ካለ የመጋዘኑን ስም ተጠቀም።
                ውጤቱን በዚህ JSON ቅርፅ ብቻ መልስ:
                {
                  "summary": "በፎቶው ላይ የተቆጠሩ እቃዎች አጭር ማብራሪያ...",
                  "received_items": {
                    "የእቃ ስም": 3
                  }
                }
            """.trimIndent()

            val raw = callGemini(apiKey, prompt, listOf(b64))
            val cleaned = cleanJson(raw)
            val json = JSONObject(cleaned)

            val summary = json.optString("summary", "እቃዎቹ ተቆጥረዋል።")
            val itemsObj = json.optJSONObject("received_items")
            val receivedMap = linkedMapOf<String, Int>()
            if (itemsObj != null) {
                itemsObj.keys().forEach { key ->
                    val count = itemsObj.optInt(key, 0)
                    if (count > 0) receivedMap[key] = count
                }
            }
            CargoComparisonResult(summaryText = summary, receivedItems = receivedMap)
        } catch (e: Exception) {
            CargoComparisonResult(
                summaryText = "",
                receivedItems = emptyMap(),
                error = "ስህተት ተፈጥሯል: ${e.message}"
            )
        }
    }

    // 3. የሽያጭ ደብተር ፎቶ አንብቦ የተሸጡ እቃዎችን ማውጣት
    suspend fun parseSalesNotebook(
        context: Context,
        notebookUri: Uri,
        currentStockNames: List<String>
    ): SalesParseResult = withContext(Dispatchers.IO) {
        val apiKey = StorageHelper.getApiKey(context)
        if (apiKey.isBlank()) {
            return@withContext SalesParseResult(
                soldItems = emptyMap(),
                error = "እባክህ መጀመሪያ ከላይ ያለውን ⚙️ (ቅንብሮች) በመጫን Gemini API Key አስገባ።"
            )
        }

        try {
            val b64 = uriToBase64(context, notebookUri)
            val stockListText = if (currentStockNames.isEmpty()) "የለም" else currentStockNames.joinToString(", ")

            val prompt = """
                ይህ የሽያጭ ደብተር ፎቶ ነው። በእጅ የተጻፉትን የተሸጡ እቃዎች እና ብዛታቸውን (Quantity) በጥንቃቄ አንብብ።
                ዋጋውን አትውሰድ፤ የተሸጠውን ብዛት (ለምሳሌ 2x1550 ከሆነ ብዛቱ 2 ነው) ብቻ ውሰድ።
                አንድ እቃ ሁለት ቦታ ከተጻፈ ብዛቱን ደምር።
                አሁን መጋዘን ውስጥ ያሉት እቃዎች ስም: [$stockListText]
                የተሸጡትን እቃዎች ከመጋዘኑ ስም ጋር አዛምድ (በአማርኛም ሆነ በእንግሊዝኛ ቢጻፉ)።
                ውጤቱን በJSON ብቻ መልስ (ምንም ተጨማሪ ጽሑፍ ሳትጨምር):
                {"የቆዳ Adidas": 4, "Amama": 6}
            """.trimIndent()

            val raw = callGemini(apiKey, prompt, listOf(b64))
            val cleaned = cleanJson(raw)
            val json = JSONObject(cleaned)

            val result = linkedMapOf<String, Int>()
            json.keys().forEach { key ->
                val qty = json.optInt(key, 0)
                if (qty > 0) result[key] = qty
            }

            if (result.isEmpty()) {
                SalesParseResult(emptyMap(), "ከፎቶው ላይ የተሸጠ እቃ ማንበብ አልተቻለም። ፎቶው ግልፅ መሆኑን አረጋግጥ።")
            } else {
                SalesParseResult(result)
            }
        } catch (e: Exception) {
            SalesParseResult(emptyMap(), "ደብተሩን ማንበብ አልተቻለም: ${e.message}")
        }
    }

    private fun cleanJson(raw: String): String {
        val trimmed = raw
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()
        val start = trimmed.indexOf('{')
        val end = trimmed.lastIndexOf('}')
        return if (start != -1 && end != -1 && end > start) {
            trimmed.substring(start, end + 1)
        } else {
            trimmed
        }
    }

    private fun callGemini(apiKey: String, prompt: String, base64Images: List<String>): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"

        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt))
        base64Images.forEach { img ->
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", img)
                )
            )
        }

        val bodyJson = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))

        val request = Request.Builder()
            .url(url)
            .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val resStr = response.body?.string() ?: throw IllegalStateException("ባዶ ምላሽ ከሰርቨር መጣ።")
            if (!response.isSuccessful) {
                throw IllegalStateException("API ስህተት (${response.code}): API Key ትክክል መሆኑን አረጋግጥ።")
            }
            val json = JSONObject(resStr)
            return json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
