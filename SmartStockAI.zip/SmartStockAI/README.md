# SmartStock AI (Android)

የተላከ እና የደረሰ እቃ ማነፃፀሪያ፣ የመጋዘን ቀሪ እቃ መከታተያ እና የሽያጭ ደብተር አንባቢ Android APK።

## ወደ APK እንዴት ይቀየራል? (በGitHub Actions)
1. ይህንን ZIP ፋይል ፍታውና ሁሉንም ፋይሎች ወደ አዲስ GitHub Repository ጫናቸው (`.github/workflows/build.yml` ሳይቀር)።
2. GitHub ላይ **Actions** የሚለውን ክፈት፤ **Build SmartStockAI APK** የሚለው ራሱ ይጀምራል (ወይም "Run workflow" ተጫን)።
3. ሲያልቅ ከታች **Artifacts** ስር `SmartStockAI-Debug-APK` የሚለውን አውርደህ ስልክህ ላይ ጫነው።
4. አፑን ስትከፍት ከላይ በቀኝ በኩል **⚙️ API Key** የሚለውን ተጭነህ ከ [Google AI Studio](https://aistudio.google.com/apikey) ያገኘኸውን ነፃ Gemini API Key አስገባ።
